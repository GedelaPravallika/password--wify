#!/usr/bin/env python3

# Platfrom Names
LINUX = 'Linux'
MAC = 'MacOS'
WINDOWS = 'Windows'

# MacOS Airport package path
AIRPORT_PATH = "/System/Library/PrivateFrameworks/Apple80211.framework/Versions/Current/Resources/airport"