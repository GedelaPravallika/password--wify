from wifi_password import main

main()
